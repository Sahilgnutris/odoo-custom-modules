from odoo import models, fields, api
import io
import xlsxwriter
from odoo.http import request, content_disposition

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    opening_balance = fields.Float(string='Opening Balance', default=0.0)
    purchase = fields.Float(string='Purchase', default=0.0)
    manufacturing = fields.Float(string='Manufacturing', default=0.0)
    purchase_return = fields.Float(string='Purchase Return', default=0.0)
    excess = fields.Float(string='Excess', default=0.0)
    sales = fields.Float(string='Sales', default=0.0)
    consumption = fields.Float(string='Consumption', default=0.0)
    sales_return = fields.Float(string='Sales Return', default=0.0)
    shortage = fields.Float(string='Shortage', default=0.0)
    closing_balance = fields.Float(string='Closing Balance', compute='_compute_closing_balance', store=True)

    @api.depends('opening_balance', 'purchase', 'manufacturing', 'purchase_return', 'excess', 'sales', 'consumption', 'sales_return', 'shortage')
    def _compute_closing_balance(self):
        for record in self:
            record.closing_balance = record.opening_balance + record.purchase + record.manufacturing - record.purchase_return + record.excess - record.sales - record.consumption + record.sales_return - record.shortage


class InventoryReport(models.AbstractModel):
    _name = 'report.inventory_report_with_filters.report_inventory'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, records):
        worksheet = workbook.add_worksheet('Inventory Report')
        bold = workbook.add_format({'bold': True})

        # Header row
        worksheet.write('A1', 'Product', bold)
        worksheet.write('B1', 'Opening Balance', bold)
        worksheet.write('C1', 'Purchase', bold)
        worksheet.write('D1', 'Manufacturing', bold)
        worksheet.write('E1', 'Purchase Return', bold)
        worksheet.write('F1', 'Excess', bold)
        worksheet.write('G1', 'Sales', bold)
        worksheet.write('H1', 'Consumption', bold)
        worksheet.write('I1', 'Sales Return', bold)
        worksheet.write('J1', 'Shortage', bold)
        worksheet.write('K1', 'Closing Balance', bold)

        # Add data from product template
        row = 1
        for product in records:
            worksheet.write(row, 0, product.name)
            worksheet.write(row, 1, product.opening_balance)
            worksheet.write(row, 2, product.purchase)
            worksheet.write(row, 3, product.manufacturing)
            worksheet.write(row, 4, product.purchase_return)
            worksheet.write(row, 5, product.excess)
            worksheet.write(row, 6, product.sales)
            worksheet.write(row, 7, product.consumption)
            worksheet.write(row, 8, product.sales_return)
            worksheet.write(row, 9, product.shortage)
            worksheet.write(row, 10, product.closing_balance)
            row += 1

        # Save and return the file
        file = io.BytesIO()
        workbook.close()
        return request.make_response(file.getvalue(), headers=[('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                                                               ('Content-Disposition', content_disposition('Inventory_Report.xlsx'))])
