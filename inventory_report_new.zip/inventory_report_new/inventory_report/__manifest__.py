{
    'name': 'Inventory Report with Filters',
    'version': '1.1',
    'depends': ['stock', 'mrp', 'report', 'product'],
    'data': [
        'views/inventory_report_view.xml',
    ],
    'installable': True,
    'auto_install': False,
}
