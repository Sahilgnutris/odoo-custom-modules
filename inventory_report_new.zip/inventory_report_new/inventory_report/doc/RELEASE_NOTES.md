## Module <inventory_report>

#### 08.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit for Inventory Report 
